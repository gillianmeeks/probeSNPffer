## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width=8, fig.height=7
)

## ----echo=FALSE, results='asis', warning=FALSE, message=FALSE-----------------
library(probeSNPffer)
library(tibble)
library(dplyr)
library(ggplot2)
knitr::kable(head(CpG_info,5)) 

## ----fig.show='hold'----------------------------------------------------------
CpG_probe_bed <- extract.probe.regions(manifest_anno_object = CpG_info)

## ----echo=FALSE, results='asis'-----------------------------------------------
knitr::kable(head(CpG_probe_bed, 5))

## ----echo=FALSE, results='asis'-----------------------------------------------
knitr::kable(head(SNP_bed, 9)) 

## ----fig.show='hold'----------------------------------------------------------
CpG_SNP_intersection <- flag.overlap(probe_bed = CpG_probe_bed, SNP_bed = SNP_bed[,1:6])
CpG_SNP_intersection <- CpG_SNP_intersection[CpG_SNP_intersection$col_chan_switching!= TRUE,]

## ----echo=F, fig.show='hold', message=F---------------------------------------
#intersect
SNP_bed <- SNP_bed[order(SNP_bed$rsid),]
CpG_SNP_intersection <- CpG_SNP_intersection[order(CpG_SNP_intersection$SNP_id),]
CpG_SNP_intersection$fst <- SNP_bed[match(CpG_SNP_intersection$SNP_id, SNP_bed$rsid), "WEIR_AND_COCKERHAM_FST"]
CpG_SNP_intersection$SNP_CpG_distance <- abs(CpG_SNP_intersection$SNP_CpG_distance)
knitr::kable(head(CpG_SNP_intersection)) 

## ----echo=F, fig.show='hold', message=F---------------------------------------
#take the closest SNP
CpG_SNP_intersection_dist  <- CpG_SNP_intersection %>% group_by(CpG_id) %>% arrange(SNP_CpG_distance)%>% slice(1)
#subset CpG_info to the probes with a SNP
CpG_info_ <- CpG_info[CpG_info$CpG_id %in% CpG_SNP_intersection_dist$CpG_id,]
CpG_info_ <- CpG_info_[order(CpG_info_$CpG_id),]
CpG_SNP_intersection_dist <- CpG_SNP_intersection_dist[order(CpG_SNP_intersection_dist$CpG_id),]
#grab the beta_geno_diff from CpG_info
beta_geno_diff <- CpG_info_[match(CpG_SNP_intersection_dist$CpG_id, CpG_info_$CpG_id), "beta_diff"]
#check order
#all.equal(CpG_SNP_intersection_dist$CpG_id, CpG_info_$CpG_id)
CpG_SNP_intersection_dist <- CpG_SNP_intersection_dist %>% add_column(beta_geno_diff)


## ----fig.show='hold', echo=F--------------------------------------------------
dist_lims = range(CpG_SNP_intersection_dist$SNP_CpG_distance)
dist_grid = seq(from = min(dist_lims), to=max(dist_lims))
model <- lm(beta_geno_diff ~ SNP_CpG_distance, data=CpG_SNP_intersection_dist)
preds = predict(model, newdata= list(SNP_CpG_distance=dist_grid), se=TRUE)
se_bands = cbind("upper" = preds$fit + (2*preds$se.fit), 
                 "lower" = preds$fit - (2*preds$se.fit))
sum <- summary(model)
sum_coeff <- sum$coefficients
ggplot() +
  geom_point(data = CpG_SNP_intersection_dist, aes(x = SNP_CpG_distance, y = beta_geno_diff), size=1) +
  geom_line(aes(x = dist_grid, y = preds$fit), color = "#0000FF") +
  geom_ribbon(aes(x = dist_grid, ymin = se_bands[,"lower"], ymax = se_bands[,"upper"]), alpha = 0.3)  +   xlim(dist_lims) + xlab("Distance of SNP to Cytosine") + ylab('Delta Effect Size') +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), plot.title=element_text(size=29), 
        legend.position = "none") + scale_y_continuous(breaks=c(0,1,2,3,4,5,6)) + annotate("text", x=20, y=3, label=paste0("R^2 = ", round(sum$r.squared,2), "\np-value = ",round(sum_coeff[2,4],4)), size=8)

## ----fig.show='hold', echo=F--------------------------------------------------
#take the highest fst snp for probes with multiple SNPs
CpG_SNP_intersection_fst  <- CpG_SNP_intersection %>% group_by(CpG_id) %>% arrange(desc(fst)) %>% slice(1)
CpG_info_ <- CpG_info[CpG_info$CpG_id %in% CpG_SNP_intersection_fst$CpG_id,]
CpG_info_ <- CpG_info_[order(CpG_info_$CpG_id),]
CpG_SNP_intersection_fst <- CpG_SNP_intersection_fst[order(CpG_SNP_intersection_fst$CpG_id),]
#take beta_geno_diff
beta_geno_diff <- CpG_info_[match(CpG_info_$CpG_id, CpG_SNP_intersection_fst$CpG_id), "beta_diff"]
#check order
#all.equal(CpG_SNP_intersection_dist$CpG_id, CpG_info_$CpG_id)
CpG_SNP_intersection_fst <- CpG_SNP_intersection_fst %>% add_column(beta_geno_diff)

## ----fig.show='hold', echo=F--------------------------------------------------
fst_lims = range(CpG_SNP_intersection_fst$fst)
fst_grid = seq(0.3,0.8,0.1)
model <- lm(beta_geno_diff ~ fst, data=CpG_SNP_intersection_fst)
preds = predict(model, newdata= list(fst=fst_grid), se=TRUE)
se_bands = cbind("upper" = preds$fit + (2*preds$se.fit), 
                 "lower" = preds$fit - (2*preds$se.fit))
sum <- summary(model)
sum_coeff <- sum$coefficients
ggplot() +
  geom_point(data = CpG_SNP_intersection_fst, aes(x = fst, y = beta_geno_diff), size=1) +
  geom_line(aes(x = fst_grid, y = preds$fit), color = "#0000FF") +
  geom_ribbon(aes(x = fst_grid, ymin = se_bands[,"lower"], ymax = se_bands[,"upper"]), alpha = 0.3) +     xlim(c(0.3,0.8)) +  xlab("Fst of SNP") + ylab('Delta Effect Size')+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), plot.title=element_text(size=29),
        legend.position = "none") + scale_y_continuous(breaks=c(0,1,2,3,4,5,6)) + annotate("text", x=.5, y=4.5, label=paste0("R^2 = ", round(sum$r.squared,2), "\np-value = ",round(sum_coeff[2,4],4)), size=8)

